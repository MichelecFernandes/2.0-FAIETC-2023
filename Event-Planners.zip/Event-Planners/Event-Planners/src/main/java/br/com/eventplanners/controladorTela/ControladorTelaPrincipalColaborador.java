package br.com.eventplanners.controladorTela;

import br.com.eventplanners.controlador.ControladorDeCena;
import javafx.fxml.FXML;

import java.io.IOException;

public class ControladorTelaPrincipalColaborador {

    @FXML
    protected void cronogramaColaborador() throws IOException {
        System.out.println("Lista de tarefas pertinentes a pessoa");
        ControladorDeCena.trocarCena("tela-lista-cronograma.fxml");
    }


    @FXML
    protected void sair() throws IOException {
        System.out.println("Voltar Tela");
        ControladorDeCena.trocarCena("tela-login.fxml");
    }
}
