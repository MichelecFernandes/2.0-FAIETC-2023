package br.com.eventplanners.controladorTela;

import br.com.eventplanners.cadastros.Cronograma;
import br.com.eventplanners.controlador.ControladorDeCena;
import br.com.eventplanners.controlador.ControladorDeDadosCronograma;
import javafx.fxml.FXML;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Tooltip;
import javafx.scene.paint.Color;


public class ControladorTelaPrincipalAdmin {

    private final ControladorDeDadosCronograma controladorDeDadosCronograma = new ControladorDeDadosCronograma();
    private ArrayList<Cronograma> cronogramas = controladorDeDadosCronograma.listarCronograma();

    @FXML
    protected void cronogramaOrganizador() throws IOException {
        System.out.println("Lista de Pessoas e Tarefas");
        ControladorDeCena.trocarCena("tela-lista-cronograma.fxml");
    }

    @FXML
    protected void controladorCredenciamento() throws IOException {
        System.out.println("Listando pessoas");
        ControladorDeCena.trocarCena("tela-lista-pessoas.fxml");
    }

    @FXML
    protected void controladorTarefa() throws IOException {
        System.out.println("Listando Tarefas");
        ControladorDeCena.trocarCena("tela-lista-tarefa.fxml");
    }

    @FXML
    protected void sair() throws IOException {
        System.out.println("Voltar Tela");
        ControladorDeCena.trocarCena("tela-login.fxml");
    }


    //qualquer coisa eu posso excluir
    //Aonde eu começo a gerar o gráfico
    @FXML
    private BarChart<String, Number> barChart;

    @FXML
    private void initialize() {
        exibirGraficoBarras();
    }

    private void exibirGraficoBarras() {


        for (XYChart.Series<String, Number> series : barChart.getData()) {
            for (XYChart.Data<String, Number> data : series.getData()) {
                Tooltip.install(data.getNode(), new Tooltip(data.getYValue() + " " + series.getName()));
            }
        }

        // Definir quantidade dos cronogramas
        int aberto = 0;
        int emAndamento = 0;
        int finalizado = 0;

        // Varre lista de cronogramas para obter a quantidade dos status
        for (Cronograma cronograma : cronogramas){
            switch (cronograma.getStatus()){
                case "Aberto": aberto += 1;
                    break;
                case "Em Andamento": emAndamento += 1;
                    break;
                case "Finalizado": finalizado += 1;
                    break;
            }
        }

        // Criar séries de dados
        XYChart.Series<String, Number> seriesAberto = new XYChart.Series<>();
        XYChart.Series<String, Number> seriesAndamento = new XYChart.Series<>();
        XYChart.Series<String, Number> seriesFinalizado = new XYChart.Series<>();

        // Definir os nomes das séries
        seriesAberto.setName("Aberto");
        seriesAndamento.setName("Em Andamento");
        seriesFinalizado.setName("Finalizado");

        // Adicionar dados às séries
        seriesAberto.getData().add(new XYChart.Data<>(Cronograma.STATUS_CRONOGRAMA.STATUS_ABERTO, aberto));
        seriesAndamento.getData().add(new XYChart.Data<>(Cronograma.STATUS_CRONOGRAMA.STATUS_EM_ANDAMENTO, emAndamento));
        seriesFinalizado.getData().add(new XYChart.Data<>(Cronograma.STATUS_CRONOGRAMA.STATUS_FINALIZADO, finalizado));

        // Adicionar as séries ao gráfico
        barChart.getData().addAll(seriesAberto, seriesAndamento, seriesFinalizado);

        // Configurar as cores para cada série
        configurarCores(seriesAberto, Color.BLUE);
        configurarCores(seriesAndamento, Color.YELLOW);
        configurarCores(seriesFinalizado, Color.GREEN);

        // Ajustar os rótulos dos eixos
        CategoryAxis xAxis = (CategoryAxis) barChart.getXAxis();
        xAxis.setLabel("Status");

        NumberAxis yAxis = (NumberAxis) barChart.getYAxis();
        yAxis.setLabel("Quantidade");
    }

    private void configurarCores(XYChart.Series<String, Number> series, Color cor) {
        for (XYChart.Data<String, Number> data : series.getData()) {
            data.getNode().setStyle("-fx-bar-fill: " + toHexString(cor) + ";");
        }
    }

    private String toHexString(Color cor) {
        return String.format("#%02X%02X%03X",
                (int) (cor.getRed() * 255),
                (int) (cor.getGreen() * 255),
                (int) (cor.getBlue() * 255));
    }


    private Map<String, Integer> contarCronogramasPorStatus() {
        Map<String, Integer> statusCounts = new HashMap<>();

        // Inicialize os contadores para cada status
        statusCounts.put(Cronograma.STATUS_CRONOGRAMA.STATUS_ABERTO, 0);
        statusCounts.put(Cronograma.STATUS_CRONOGRAMA.STATUS_EM_ANDAMENTO, 0);
        statusCounts.put(Cronograma.STATUS_CRONOGRAMA.STATUS_FINALIZADO, 0);

        // Percorra a lista de cronogramas e conte os que têm o status correspondente
        Cronograma[] listaDeCronogramas = new Cronograma[0];
        for (Cronograma cronograma : listaDeCronogramas) {
            String status = cronograma.getStatus();
            statusCounts.put(status, statusCounts.get(status) + 1);
        }

        return statusCounts;
    }



}

