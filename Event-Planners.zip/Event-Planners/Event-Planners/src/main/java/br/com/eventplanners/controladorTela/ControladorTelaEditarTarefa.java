package br.com.eventplanners.controladorTela;

import br.com.eventplanners.cadastros.Cronograma;
import br.com.eventplanners.cadastros.CronogramaPessoa;
import br.com.eventplanners.cadastros.Pessoa;
import br.com.eventplanners.cadastros.Tarefa;
import br.com.eventplanners.controlador.*;
import br.com.eventplanners.manipulacaoArquivo.ControladorArquivoPessoa;
import br.com.eventplanners.manipulacaoArquivo.ControladorArquivoTarefa;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.Callback;

import java.io.IOException;
import java.util.ArrayList;

public class ControladorTelaEditarTarefa {

    public static Tarefa tarefa;

    @FXML
    private TextField editarNomeTarefa;

    @FXML
    private TextField editarValorTarefa;

    @FXML
    private Button btnSalvarEditarTarefa;

    private ArrayList<Tarefa> tarefas = ControladorArquivoTarefa.lerArquivoTarefas();

    private int idTarefa = -1;

    @FXML
    public void initialize(){

        tarefas = ControladorArquivoTarefa.lerArquivoTarefas();

        if(tarefas == null){
            return;
        }
        editarNomeTarefa.setText(tarefa.getNomeTarefa());
        editarValorTarefa.setText(String.valueOf(tarefa.getValorTarefa()));



        btnSalvarEditarTarefa.setOnAction(actionEvent -> {
            try {
                editarTarefa(tarefa);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });




    }

    @FXML
    public void salvarEdicaoListaTarefa() throws IOException {
        Tarefa tarefa = new Tarefa(
                editarNomeTarefa.getText(),
                Double.parseDouble(editarValorTarefa.getText()));
        ControladorDeDadosTarefa controladorDeDadosTarefa = new ControladorDeDadosTarefa();
        controladorDeDadosTarefa.atualizarTarefa(tarefa);

        ControladorDeDadosTarefa tarefa1 = new ControladorDeDadosTarefa();
        tarefa1.atualizarTarefa(tarefa);
        ControladorDeCena.trocarCena("tela-lista-tarefa.fxml");
    }

    @FXML
    protected void voltarTelaListaTarefa() throws IOException {
        System.out.println("Voltar Tela lista Tarefas");
        ControladorDeCena.trocarCena("tela-lista-tarefa.fxml");
    }



    private void editarTarefa(Tarefa tarefa) throws IOException{

        tarefa.setNomeTarefa(editarNomeTarefa.getText());
        tarefa.setValorTarefa(Double.parseDouble(editarValorTarefa.getText()));

        ControladorDeDadosTarefa controladorDeDadosTarefa = new ControladorDeDadosTarefa();
        if(!controladorDeDadosTarefa.atualizarTarefa(tarefa)){
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setTitle("Error");
            alerta.setHeaderText("Erro ao editar os dados da tarefa");
            alerta.setContentText("verifique os seus dados");
            alerta.show();
            return;
        }

        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle("SUCESSO");
        alerta.setHeaderText("Atualização dos dados da tarefa feita com sucesso!");
        alerta.setContentText("A atualização foi concluída!");
        alerta.show();
        ControladorDeCena.trocarCena("tela-lista-tarefa.fxml");
    }


}
