package br.com.eventplanners.controladorTela;

import br.com.eventplanners.controlador.ControladorDeCena;
import br.com.eventplanners.controlador.ControladorLogin;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

import java.io.IOException;

public class ControladorTelaLogin {

    //Responsavel por pegar o valor do campo do usuario
    @FXML
    private TextField inputUsuario;

    @FXML
    private PasswordField inputSenha;

    @FXML
    //Se usuario
    protected void entrarNoSistema() throws IOException {
        String usuario = inputUsuario.getText();
        String senha = inputSenha.getText();

        ControladorLogin controladorLogin = new ControladorLogin();

        if (controladorLogin.entrarNoSistema(usuario,senha)){
            initialize();
            if (usuario.equals("admin")){
                ControladorDeCena.trocarCena("tela-principal-admin.fxml");
            }else{
                ControladorDeCena.trocarCena("tela-lista-cronograma-colaborador.fxml");
            }



        } else {
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setTitle("Error");
            alerta.setHeaderText("Erro ao realizar Login");
            alerta.setContentText("Usuário e/ou senha inválido(s)!");
            alerta.show();
        }
    }

    @FXML
    private void initialize() {
        // Adicione um evento de tecla pressionada ao campo de senha
        inputSenha.setOnKeyPressed(event -> {
            try {
                handleKeyPressed(event);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }
    private void handleKeyPressed(KeyEvent event) throws IOException {
        if (event.getCode() == KeyCode.ENTER) {
            // A tecla Enter foi pressionada, chame o método entrarNoSistema
            entrarNoSistema();
        }
    }
}
